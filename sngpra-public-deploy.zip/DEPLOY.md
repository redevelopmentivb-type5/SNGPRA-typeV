# Deploy SNGPRA Type-V Complaint Portal

This folder is ready for a Node.js public server.

## Files to Upload

- `index.html`
- `server.mjs`
- `package.json`
- `complaints.json`
- `API_README.md`

## Server Settings

Start command:

```text
npm start
```

Environment variables:

```text
ADMIN_EMAIL=redevelopmentivb@gmail.com
ADMIN_PASSWORD=change-this-password
```

The hosting provider should set `PORT` automatically. The server listens on `0.0.0.0`.

## Public URLs After Deployment

Replace `https://your-domain.com` with your domain:

```text
https://your-domain.com/
https://your-domain.com/api/health
https://your-domain.com/api/complaints
https://your-domain.com/api/complaints/export.csv
```

## Important Production Note

This app stores complaints in `complaints.json`. That is acceptable for a small demo or single-server deployment. For real public use, use a database so complaints are not lost if the host restarts or replaces the server.
