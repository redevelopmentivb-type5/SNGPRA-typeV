# SNGPRA Type-V Complaint API

Base URL while running locally:

```text
http://127.0.0.1:4176
```

For public sharing, deploy this folder to a Node.js host and replace the base URL with your public domain.

## Public Endpoints

### Health Check

```http
GET /api/health
```

### Submit Complaint

```http
POST /api/complaints
Content-Type: application/json
```

```json
{
  "resident": "Resident Name",
  "tower": "21",
  "flat": "0104",
  "category": "Electrical",
  "issue": "MCB tripping",
  "priority": "Medium",
  "recurring": "No",
  "oldTrackingId": "-"
}
```

## Admin Endpoints

Admin requests require these headers:

```http
X-Admin-Email: redevelopmentivb@gmail.com
X-Admin-Password: admin123
```

### List Complaints

```http
GET /api/complaints
```

### Resolve Complaint

```http
PATCH /api/complaints/CMP-101/resolve
```

### Download Excel-Compatible CSV

```http
GET /api/complaints/export.csv
```

## Data Storage

Complaints are saved in:

```text
complaints.json
```
